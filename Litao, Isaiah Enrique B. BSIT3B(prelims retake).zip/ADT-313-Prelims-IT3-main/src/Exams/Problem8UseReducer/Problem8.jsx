import { useReducer } from 'react';
import data from './problem8mock_data.json';

const foodReducer = (state, action) => {
  switch (action.type) {
    case 'ADD_FOOD':
      return {
        ...state,
        foods: [...state.foods, action.payload], 
      };
    case 'UPDATE_FOOD':
      return {
        ...state,
        foods: state.foods.map((food) =>
          food.id === action.payload.id ? { ...food, ...action.payload } : food
        ), 
        selected: action.payload
      };
    case 'DELETE_FOOD':
      return {
        ...state,
        foods: state.foods.filter((food) => food.id !== action.payload.id), // Remove the food from the list
        selected: null, 
      };
    case 'SELECT_FOOD':
      return {
        ...state,
        selected: action.payload
      };
    case 'CLEAR_FORM':
      return {
        ...state,
        selected: null
      };
    default:
      return state;
  }
};

export default function Problem8() {
  const [state, dispatch] = useReducer(foodReducer, {
    foods: data,
    selected: null,
  });

  const { foods, selected } = state;

  const handleInputChange = (e) => {
    if (selected) {

      dispatch({
        type: 'SELECT_FOOD',
        payload: { ...selected, [e.target.name]: e.target.value },
      });
    }
  };

  const handleSave = () => {
    if (selected) {
      dispatch({ type: 'UPDATE_FOOD', payload: selected });
    } else {
      const newFood = {
        id: Date.now(), 
        food_name: '',
        price: '',
        expiration_date: '',
        calories: '',
      };
      dispatch({ type: 'ADD_FOOD', payload: newFood });
    }
  };

  const handleEdit = (food) => {
    dispatch({ type: 'SELECT_FOOD', payload: food });
  };


  const handleDelete = (food) => {
    dispatch({ type: 'DELETE_FOOD', payload: food });
  };

  const handleClear = () => {
    dispatch({ type: 'CLEAR_FORM' });
  };

  return (
    <>
      <div>
        <div style={{ display: 'block' }}>
          Food Name:
          <input
            type="text"
            name="food_name"
            value={selected ? selected.food_name : ''}
            onChange={handleInputChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Price:
          <input
            type="text"
            name="price"
            value={selected ? selected.price : ''}
            onChange={handleInputChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Expiration Date:
          <input
            type="text"
            name="expiration_date"
            value={selected ? selected.expiration_date : ''}
            onChange={handleInputChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Calories:
          <input
            type="text"
            name="calories"
            value={selected ? selected.calories : ''}
            onChange={handleInputChange}
          />
        </div>

        <button type="button" onClick={handleSave}>
          {selected ? 'Update' : 'Save'}
        </button>
        <button type="button" onClick={handleClear}>
          Clear
        </button>
      </div>

      <div className="table-container">
        <table style={{ width: '100%' }}>
          <thead>
            <tr>
              <th>Food Name</th>
              <th>Price</th>
              <th>Expiration Date</th>
              <th>Calories</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody style={{ textAlign: 'center' }}>
            {foods.map((food) => (
              <tr key={food.id}>
                <td>{food.food_name}</td>
                <td>{food.price}</td>
                <td>{food.expiration_date}</td>
                <td>{food.calories}</td>
                <td>
                  <button type="button" onClick={() => handleEdit(food)}>
                    Edit
                  </button>
                  <button type="button" onClick={() => handleDelete(food)}>
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
