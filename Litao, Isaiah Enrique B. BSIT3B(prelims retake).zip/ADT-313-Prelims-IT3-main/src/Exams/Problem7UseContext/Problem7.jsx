import React, { useState } from 'react';
import Lists from './Problem7Components/Lists';
import SelectedValue from './Problem7Components/Selected';
import data from './problem7_mock_data.json'; 

export default function Problem7() {
  const [selectedData, setSelectedData] = useState(null); 
  const [mockData] = useState(data); 

  return (
    <>
      <p>Apply UseContext here</p>

      <div style={{ display: 'block' }}>
        <SelectedValue selectedData={selectedData} />
      </div>
      <div style={{ display: 'block' }}>
        <Lists data={mockData} setSelectedData={setSelectedData} />
      </div>
    </>
  );
}
