function SelectedValue({ selectedData }) {
  return selectedData ? (
    <div style={{ display: 'flex', width: '100%', justifyContent: 'space-around' }}>
      <div>
        <p>Title: {selectedData.title}</p>
        <p>Genre: {selectedData.genre}</p>
        <p>Release Date: {selectedData.release_date}</p>
        <p>Director: {selectedData.director}</p>
        <p>Actor 1: {selectedData.actor_1}</p>
      </div>
      <div>
        <p>Actor 2: {selectedData.actor_2}</p>
        <p>Rating: {selectedData.rating}</p>
        <p>Box Office: {selectedData.box_office}</p>
        <p>Duration(Minutes): {selectedData.duration_minutes}</p>
        <p>Language: {selectedData.language}</p>
      </div>
    </div>
  ) : (
    <p>Display Selected Component</p> 
  );
}

export default SelectedValue;
