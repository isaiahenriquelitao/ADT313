import { useState } from 'react';
import './Register.css';
import axios from 'axios';

function Register() {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    firstName: '',
    lastName: '',
    middleName: '',
    contactNo: '',
    role: 'user',
  });

  const [status, setStatus] = useState('idle');
  const [errors, setErrors] = useState({});
  const [isFieldsDirty, setIsFieldsDirty] = useState(false);

  const validateFields = () => {
    let errors = {};
    if (!formData.email) errors.email = 'Email is required';
    if (!formData.password) errors.password = 'Password is required';
    if (!formData.firstName) errors.firstName = 'First Name is required';
    if (!formData.lastName) errors.lastName = 'Last Name is required';
    if (!formData.contactNo) errors.contactNo = 'Contact Number is required';
    return errors;
  };

  const handleOnChange = (event) => {
    setIsFieldsDirty(true);
    const { name, value } = event.target;
    setFormData((prevState) => ({
      ...prevState,
      [name]: value,
    }));
    setErrors((prevErrors) => ({ ...prevErrors, [name]: '' }));
  };

  const handleRegister = async () => {
    const validationErrors = validateFields();
    if (Object.keys(validationErrors).length === 0) {
      setStatus('loading');
      try {
        await axios.post('http://localhost/movieproject-api/register.php', formData, {
          headers: { 'Content-Type': 'application/json' },
        });
        setStatus('success');
        alert('User registered successfully');
      } catch (error) {
        console.log(error);
        setStatus('error');
        alert('Failed to register');
      }
    } else {
      setErrors(validationErrors);
      setIsFieldsDirty(true);
    }
  };

  return (
    <div className="Register">
      <div className="main-container">
        <h3>Register</h3>
        <form>
          <div className="form-container">
            <FormField
              label="Email"
              type="email"
              name="email"
              value={formData.email}
              onChange={handleOnChange}
              error={errors.email}
              required
            />
            <FormField
              label="Password"
              type="password"
              name="password"
              value={formData.password}
              onChange={handleOnChange}
              error={errors.password}
              required
            />
            <FormField
              label="First Name"
              type="text"
              name="firstName"
              value={formData.firstName}
              onChange={handleOnChange}
              error={errors.firstName}
              required
            />
            <FormField
              label="Last Name"
              type="text"
              name="lastName"
              value={formData.lastName}
              onChange={handleOnChange}
              error={errors.lastName}
              required
            />
            <FormField
              label="Middle Name"
              type="text"
              name="middleName"
              value={formData.middleName}
              onChange={handleOnChange}
              error={errors.middleName}
            />
            <FormField
              label="Contact"
              type="text"
              name="contactNo"
              value={formData.contactNo}
              onChange={handleOnChange}
              error={errors.contactNo}
              required
            />
            <div className="submit-container">
              <button
                type="button"
                onClick={handleRegister}
                disabled={status === 'loading' || !isFieldsDirty}
              >
                {status === 'loading' ? 'Loading...' : 'Register'}
              </button>
              {status === 'error' && <p className="error-message">Registration failed. Please try again.</p>}
              {status === 'success' && <p className="success-message">Registration successful!</p>}
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}

function FormField({ label, type, name, value, onChange, error, required }) {
  return (
    <div className="form-group">
      <label>
        {label}: {required && <span className="required"></span>}
      </label>
      <input type={type} name={name} value={value} onChange={onChange} required={required} />
      {error && <span className="error">{error}</span>}
    </div>
  );
}

export default Register;
