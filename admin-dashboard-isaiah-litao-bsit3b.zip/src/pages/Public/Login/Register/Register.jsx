import { useState } from 'react';
import axios from 'axios';
import './Register.css';

function Register() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [firstName, setFirstName] = useState('');
  const [middleName, setMiddleName] = useState('');
  const [lastName, setLastName] = useState('');
  const [contactNumber, setContactNumber] = useState('');
  const [status, setStatus] = useState('idle');

  const handleRegister = async () => {
    const data = { email, password, firstName, middleName, lastName, contactNumber };
    setStatus('loading');

    await axios({
      method: 'post',
      url: '/register',
      data,
      headers: { 'Access-Control-Allow-Origin': '*' },
    })
      .then((res) => {
        console.log(res);
        setStatus('idle');
        alert('Registration Successful');
      })
      .catch((e) => {
        console.log(e);
        setStatus('idle');
        alert(e.response.data.message);
      });
  };

  return (
    <div className='Register'>
      <div className='main-container'>
        <h3>Register</h3>
        <form>
          <div className='form-container'>
            <div className='form-group'>
              <label>E-mail:</label>
              <input
                type='email'
                name='email'
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <div className='form-group'>
              <label>Password:</label>
              <input
                type='password'
                name='password'
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
            <div className='form-group'>
              <label>First Name:</label>
              <input
                type='text'
                name='firstName'
                onChange={(e) => setFirstName(e.target.value)}
              />
            </div>
            <div className='form-group'>
              <label>Middle Name:</label>
              <input
                type='text'
                name='middleName'
                onChange={(e) => setMiddleName(e.target.value)}
              />
            </div>
            <div className='form-group'>
              <label>Last Name:</label>
              <input
                type='text'
                name='lastName'
                onChange={(e) => setLastName(e.target.value)}
              />
            </div>
            <div className='form-group'>
              <label>Contact No.:</label>
              <input
                type='text'
                name='contactNumber'
                onChange={(e) => setContactNumber(e.target.value)}
              />
            </div>
            <div className='submit-container'>
              <button
                type='button'
                disabled={status === 'loading'}
                onClick={handleRegister}
              >
                {status === 'idle' ? 'Register' : 'Loading'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}

export default Register;